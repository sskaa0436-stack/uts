// Logika Game Tic-Tac-Toe
const boardElement = document.getElementById('board');
const cells = document.querySelectorAll('.cell');
const statusElement = document.getElementById('status');
const resetBtn = document.getElementById('reset-btn');
const musicBtn = document.getElementById('music-btn');
const difficultySelect = document.getElementById('difficulty');
const gameContainer = document.querySelector('.game-container');
const confettiCanvas = document.getElementById('confetti');

const scorePlayerEl = document.getElementById('score-player');
const scoreTieEl = document.getElementById('score-tie');
const scoreAiEl = document.getElementById('score-ai');

let board = ['', '', '', '', '', '', '', '', ''];
let isHumanTurn = true; // Player 'X' jalan duluan
let isGameActive = true;
let aiTurnTimeout = null;

const HUMAN = 'X';
const AI = 'O';

// Kombinasi garis kemenangan
const winningConditions = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Baris
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Kolom
    [0, 4, 8], [2, 4, 6]            // Diagonal
];

const scoreStorageKey = 'ticTacToeScores';
const difficultyStorageKey = 'ticTacToeDifficulty';
let scores = { player: 0, tie: 0, ai: 0 };

try {
    localStorage.removeItem(scoreStorageKey);
} catch (error) {
    console.error('Skor lama tidak dapat dihapus:', error);
}

let audioContext = null;
let musicEnabled = false;
let musicInterval = null;
let musicStep = 0;
let confettiFrame = null;
let confettiTimeout = null;
const musicMelody = [523.25, 659.25, 783.99, 659.25, 587.33, 698.46, 783.99, 698.46];
const soundNotes = {
    player: [{ frequency: 660, delay: 0 }],
    ai: [{ frequency: 440, delay: 0 }],
    win: [
        { frequency: 523, delay: 0 },
        { frequency: 659, delay: 0.12 },
        { frequency: 784, delay: 0.24 }
    ],
    lose: [
        { frequency: 440, delay: 0 },
        { frequency: 349, delay: 0.12 },
        { frequency: 262, delay: 0.24 }
    ],
    tie: [
        { frequency: 392, delay: 0 },
        { frequency: 392, delay: 0.16 }
    ],
    reset: [{ frequency: 523, delay: 0 }]
};

// Event listener untuk klik sel papan
cells.forEach(cell => {
    cell.addEventListener('click', handleCellClick);
});

resetBtn.addEventListener('click', resetGame);
musicBtn.addEventListener('click', toggleMusic);
difficultySelect.addEventListener('change', () => {
    try {
        localStorage.setItem(difficultyStorageKey, difficultySelect.value);
    } catch (error) {
        console.error('Pilihan tingkat kesulitan tidak dapat disimpan:', error);
    }

    resetGame();
    statusElement.textContent = `Mode ${getDifficultyName()}. Giliran Anda (X)`;
});

loadDifficulty();
updateScoreboard();

function handleCellClick(e) {
    const index = e.target.getAttribute('data-index');

    if (board[index] !== '' || !isGameActive || !isHumanTurn) return;

    makeMove(index, HUMAN);

    if (checkWin(board, HUMAN)) {
        endGame('player');
        return;
    } else if (checkTie(board)) {
        endGame('tie');
        return;
    }

    isHumanTurn = false;
    statusElement.textContent = "Giliran AI (O) Berpikir...";

    // Beri jeda sedikit agar terasa natural seperti mikir
    aiTurnTimeout = setTimeout(() => {
        aiTurnTimeout = null;
        if (!isGameActive || isHumanTurn) return;

        const bestMove = chooseAiMove();
        if (bestMove === null) {
            endGame('tie');
            return;
        }
        makeMove(bestMove, AI);

        if (checkWin(board, AI)) {
            endGame('ai');
            return;
        } else if (checkTie(board)) {
            endGame('tie');
            return;
        }

        isHumanTurn = true;
        statusElement.textContent = `Mode ${getDifficultyName()}. Giliran Anda (X)`;
    }, 400);
}

function makeMove(index, player) {
    board[index] = player;
    cells[index].textContent = player;
    cells[index].setAttribute('aria-label', `Kotak ${Number(index) + 1}: ${player}`);
    cells[index].classList.add(player.toLowerCase());
    cells[index].classList.remove('pop');
    void cells[index].offsetWidth;
    cells[index].classList.add('pop');
    playSound(player === HUMAN ? 'player' : 'ai');
}

function checkWin(currentBoard, player) {
    return getWinningLine(currentBoard, player) !== null;
}

function getWinningLine(currentBoard, player) {
    return winningConditions.find(condition =>
        condition.every(index => currentBoard[index] === player)
    ) || null;
}

function checkTie(currentBoard) {
    return currentBoard.every(cell => cell !== '');
}

function endGame(winner) {
    isGameActive = false;
    playSound(winner === 'player' ? 'win' : winner === 'ai' ? 'lose' : 'tie');
    statusElement.classList.remove('draw-result');
    if (winner === 'player') {
        statusElement.textContent = "Selamat, Anda Menang!";
        highlightWinningLine(HUMAN);
        gameContainer.classList.add('celebrate');
        launchConfetti();
        scores.player++;
        updateScoreboard();
    } else if (winner === 'ai') {
        statusElement.textContent = "AI Menang! Coba Lagi.";
        highlightWinningLine(AI);
        scores.ai++;
        updateScoreboard();
    } else {
        statusElement.textContent = "🤝 Hasil Seri!";
        statusElement.classList.add('draw-result');
        cells.forEach(cell => cell.classList.add('draw-cell'));
        scores.tie++;
        updateScoreboard();
    }
}

function resetGame() {
    playSound('reset');
    stopConfetti();
    gameContainer.classList.remove('celebrate');

    if (aiTurnTimeout !== null) {
        clearTimeout(aiTurnTimeout);
        aiTurnTimeout = null;
    }

    board = ['', '', '', '', '', '', '', '', ''];
    isGameActive = true;
    isHumanTurn = true;
    statusElement.textContent = `Mode ${getDifficultyName()}. Giliran Anda (X)`;
    statusElement.classList.remove('draw-result');
    
    cells.forEach(cell => {
        cell.textContent = '';
        cell.setAttribute('aria-label', `Kotak ${Number(cell.getAttribute('data-index')) + 1}`);
        cell.classList.remove('x', 'o', 'pop', 'winning-cell', 'draw-cell');
    });
}

function chooseAiMove() {
    if (difficultySelect.value === 'easy') {
        return chooseRandomMove(board);
    }

    if (difficultySelect.value === 'medium') {
        const winningMove = findImmediateMove(AI);
        if (winningMove !== null) return winningMove;

        const blockingMove = findImmediateMove(HUMAN);
        if (blockingMove !== null) return blockingMove;

        return chooseRandomMove(board);
    }

    return minimaxBestMove();
}

function chooseRandomMove(currentBoard) {
    const availableMoves = currentBoard
        .map((cell, index) => cell === '' ? index : null)
        .filter(index => index !== null);
    if (availableMoves.length === 0) return null;
    return availableMoves[Math.floor(Math.random() * availableMoves.length)];
}

function findImmediateMove(player) {
    for (let index = 0; index < board.length; index++) {
        if (board[index] !== '') continue;
        board[index] = player;
        const wins = checkWin(board, player);
        board[index] = '';
        if (wins) return index;
    }
    return null;
}

function getDifficultyName() {
    return {
        easy: 'Santai',
        medium: 'Sedang',
        hard: 'Sulit'
    }[difficultySelect.value];
}

function loadDifficulty() {
    try {
        const savedDifficulty = localStorage.getItem(difficultyStorageKey);
        if (['easy', 'medium', 'hard'].includes(savedDifficulty)) {
            difficultySelect.value = savedDifficulty;
        }
    } catch (error) {
        console.error('Pilihan tingkat kesulitan tidak dapat dimuat:', error);
    }
    statusElement.textContent = `Mode ${getDifficultyName()}. Giliran Anda (X)`;
}

function updateScoreboard() {
    scorePlayerEl.textContent = scores.player;
    scoreTieEl.textContent = scores.tie;
    scoreAiEl.textContent = scores.ai;
}

function highlightWinningLine(player) {
    const line = getWinningLine(board, player);
    if (line) line.forEach(index => cells[index].classList.add('winning-cell'));
}

function launchConfetti() {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const context = confettiCanvas.getContext('2d');
    if (!context) return;

    const pixelRatio = window.devicePixelRatio || 1;
    confettiCanvas.width = window.innerWidth * pixelRatio;
    confettiCanvas.height = window.innerHeight * pixelRatio;
    confettiCanvas.style.width = `${window.innerWidth}px`;
    confettiCanvas.style.height = `${window.innerHeight}px`;
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);

    const colors = ['#38bdf8', '#f43f5e', '#facc15', '#a78bfa', '#4ade80'];
    const particles = Array.from({ length: 100 }, () => ({
        x: Math.random() * window.innerWidth,
        y: -Math.random() * window.innerHeight * 0.6,
        size: 4 + Math.random() * 6,
        speed: 2 + Math.random() * 4,
        drift: (Math.random() - 0.5) * 2,
        rotation: Math.random() * Math.PI,
        spin: (Math.random() - 0.5) * 0.12,
        color: colors[Math.floor(Math.random() * colors.length)]
    }));
    const startTime = performance.now();

    function drawConfetti(time) {
        context.clearRect(0, 0, window.innerWidth, window.innerHeight);
        particles.forEach(particle => {
            particle.x += particle.drift;
            particle.y += particle.speed;
            particle.rotation += particle.spin;
            context.save();
            context.translate(particle.x, particle.y);
            context.rotate(particle.rotation);
            context.fillStyle = particle.color;
            context.fillRect(-particle.size / 2, -particle.size / 2, particle.size, particle.size * 0.65);
            context.restore();
        });

        if (time - startTime < 2200) {
            confettiFrame = requestAnimationFrame(drawConfetti);
        } else {
            stopConfetti();
        }
    }

    confettiFrame = requestAnimationFrame(drawConfetti);
    confettiTimeout = setTimeout(stopConfetti, 2500);
}

function stopConfetti() {
    if (confettiFrame !== null) {
        cancelAnimationFrame(confettiFrame);
        confettiFrame = null;
    }
    if (confettiTimeout !== null) {
        clearTimeout(confettiTimeout);
        confettiTimeout = null;
    }

    const context = confettiCanvas.getContext('2d');
    if (context) context.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
}

function toggleMusic() {
    musicEnabled = !musicEnabled;
    musicBtn.textContent = musicEnabled ? '♫ Musik: Nyala' : '♫ Musik: Mati';
    musicBtn.setAttribute('aria-pressed', String(musicEnabled));

    if (!musicEnabled) {
        clearInterval(musicInterval);
        musicInterval = null;
        return;
    }

    try {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextClass) {
            throw new Error('Audio tidak didukung oleh browser ini.');
        }
        if (!audioContext) audioContext = new AudioContextClass();

        audioContext.resume().then(() => {
            if (!musicEnabled || musicInterval !== null) return;
            playMusicNote();
            musicInterval = setInterval(playMusicNote, 480);
        }).catch(error => {
            musicEnabled = false;
            musicBtn.textContent = '♫ Musik: Mati';
            musicBtn.setAttribute('aria-pressed', 'false');
            console.error('Musik tidak dapat dijalankan:', error);
        });
    } catch (error) {
        musicEnabled = false;
        musicBtn.textContent = '♫ Musik: Mati';
        musicBtn.setAttribute('aria-pressed', 'false');
        console.error('Musik tidak dapat dijalankan:', error);
    }
}

function playMusicNote() {
    if (!musicEnabled || !audioContext || audioContext.state !== 'running') return;

    const now = audioContext.currentTime;
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();

    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(musicMelody[musicStep], now);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.055, now + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.42);
    oscillator.connect(gain);
    gain.connect(audioContext.destination);
    oscillator.start(now);
    oscillator.stop(now + 0.43);
    musicStep = (musicStep + 1) % musicMelody.length;
}

function playSound(type) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) {
        console.warn('Efek suara tidak didukung oleh browser ini.');
        return;
    }

    try {
        if (!audioContext) {
            audioContext = new AudioContextClass();
        }

        if (audioContext.state === 'suspended') {
            audioContext.resume().catch(error => {
                console.error('Audio tidak dapat dijalankan:', error);
            });
        }

        const now = audioContext.currentTime;
        soundNotes[type].forEach(note => {
            const oscillator = audioContext.createOscillator();
            const gain = audioContext.createGain();
            const startTime = now + note.delay;

            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(note.frequency, startTime);
            gain.gain.setValueAtTime(0.0001, startTime);
            gain.gain.exponentialRampToValueAtTime(0.3, startTime + 0.015);
            gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.18);
            oscillator.connect(gain);
            gain.connect(audioContext.destination);
            oscillator.start(startTime);
            oscillator.stop(startTime + 0.19);
        });
    } catch (error) {
        console.error('Gagal memutar efek suara:', error);
    }
}

/* --- Implementasi Algoritma Minimax untuk AI Sempurna --- */
function minimaxBestMove() {
    let bestScore = -Infinity;
    let move = null;

    for (let i = 0; i < board.length; i++) {
        if (board[i] === '') {
            board[i] = AI;
            let score = minimax(board, 0, false);
            board[i] = '';
            if (score > bestScore) {
                bestScore = score;
                move = i;
            }
        }
    }
    return move;
}

function minimax(currentBoard, depth, isMaximizing) {
    if (checkWin(currentBoard, AI)) return 10 - depth;
    if (checkWin(currentBoard, HUMAN)) return depth - 10;
    if (checkTie(currentBoard)) return 0;

    if (isMaximizing) {
        let maxScore = -Infinity;
        for (let i = 0; i < currentBoard.length; i++) {
            if (currentBoard[i] === '') {
                currentBoard[i] = AI;
                let score = minimax(currentBoard, depth + 1, false);
                currentBoard[i] = '';
                maxScore = Math.max(score, maxScore);
            }
        }
        return maxScore;
    } else {
        let minScore = Infinity;
        for (let i = 0; i < currentBoard.length; i++) {
            if (currentBoard[i] === '') {
                currentBoard[i] = HUMAN;
                let score = minimax(currentBoard, depth + 1, true);
                currentBoard[i] = '';
                minScore = Math.min(score, minScore);
            }
        }
        return minScore;
    }
}